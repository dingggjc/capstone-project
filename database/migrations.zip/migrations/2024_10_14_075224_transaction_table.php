<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transaction_table', function (Blueprint $table) {
            $table->id('transaction_id');
            $table->unsignedBigInteger('id');
            $table->unsignedBigInteger('product_id');
            $table->unsignedBigInteger('package_id');
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('vehicle_id');
            $table->string('invoice');
            $table->bigInteger('cash');
            $table->bigInteger('change');
            $table->bigInteger('discount');
            $table->bigInteger('grand_total');
            $table->timestamps();
            $table->integer('total_amount');
            $table->foreign('id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('product_id')->references('product_inventory_id')->on('product_inventory')->onDelete('cascade');
            $table->foreign('package_id')->references('package_id')->on('t_package')->onDelete('cascade');
            $table->foreign('customer_id')->references('customer_id')->on('customers')->onDelete('cascade');
            $table->foreign('vehicle_id')->references('vehicle_id')->on('vehicle_table')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transaction_table');
    }
};